#!/usr/bin/python

import glob

print glob.glob("./*.py")