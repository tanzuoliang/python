#!/usr/bin/python
#encoding=utf-8
from myutil import utils
utils.syncDir('a', '我是谁')
