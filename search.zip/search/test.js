
var print = function () {
	
}

function showname(str){
	cc.log("if you can not find " + str); var j = 345;
	var i = 123;cc.log("ysj");
	return i + 256
//	cc.log("hahahaha"
//	+ " 122");
	var ii = 345;
}


